<p align="center"> <a href="#"><img title="HAXOR" src="https://raw.githubusercontent.com/shariat1/dako-to-sahi/master/PicsArt_05-07-11.14.06.png?token=AKJCAT75HWCPRGL237W5EDS6WOV4K"> </a> </p> <br>

## Installation

* `apt update`
* `apt upgrade -y`
* `apt install git -y`
* `cd $HOME`
* `git clone https://gitlab.com/darknethaxor/night-rage.git`
* `cd night-rage`
* `chmod +x setup.sh`
* `bash setup.sh`

## For Run

* `rage`
